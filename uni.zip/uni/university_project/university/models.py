from django.db import models

class Profile(models.Model):
    phone_number = models.CharField(max_length=20)
    address = models.CharField(max_length=255)

    def __str__(self):
        return self.phone_number


class Student(models.Model):
    name = models.CharField(max_length=50)
    surname = models.CharField(max_length=50)
    birth_date = models.DateField()
    profile = models.OneToOneField(Profile, on_delete=models.CASCADE, related_name="student")

    def __str__(self):
        return f"{self.name} {self.surname}"


class Course(models.Model):
    title = models.CharField(max_length=100)
    description = models.TextField(blank=True, null=True)

    def __str__(self):
        return self.title


class Professor(models.Model):
    name = models.CharField(max_length=50)
    surname = models.CharField(max_length=50)
    courses = models.ManyToManyField(Course, related_name="professors")

    def __str__(self):
        return f"{self.name} {self.surname}"


class Class(models.Model):
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name="classes")
    students = models.ManyToManyField(Student, related_name="classes")

    def __str__(self):
        return f"Class for {self.course.title}"
